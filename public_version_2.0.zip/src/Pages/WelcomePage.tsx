import React from "react";
import { Welcome } from "../Components/Welcome";

export function WelcomePage() {
    return (<>
    <Welcome></Welcome>
    </>)
}