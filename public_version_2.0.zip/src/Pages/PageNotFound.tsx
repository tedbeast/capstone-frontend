import React from "react";
export function PageNotFoundPage(){
    return (<>
    <h1>Sorry, that page does not exist</h1></>)
}