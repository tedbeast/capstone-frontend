import React from "react";

export function Welcome() {
    return (<>
    <h1 style={{padding:20, textAlign:"center"}}>Welcome!</h1>
    </>)
}