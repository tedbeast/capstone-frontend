export interface Manager {
  managerID: number;
  managerEmployeeId: number;
  employeesIds: number[];
}
